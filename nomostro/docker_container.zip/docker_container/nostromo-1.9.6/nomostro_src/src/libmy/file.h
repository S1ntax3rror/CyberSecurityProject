int	flog(const char *, const char *, ...);
int	flogd(const char *, const char *, ...);
int	fparse(char *, const char *, const char *, const int);
